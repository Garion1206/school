## 0.1 课前提问

>[!question]- Question 1：块元素 flow 的特点，内联元素 flow 的特点，这两种元素集成后的 flow。

>[!question]- Question 2： 简述 margin 样式在不同元素不同方向上的计算差别。
> 答： 
>  * inline 元素，水平方向，margin 是两者相加
>  * block 元素，垂直方向，margin 是以两者中 margin 值大的那个为准
>  * block 元素互相嵌套， 无 border 时两者相加，有 border 时取较大值。

___

## 0.2 课程引入

要理解 float，必须先了解 flow，相信通过一堂课的学习，各位对 flow 已经有了自己的认识，我们终于可以更深入得来讨论 float 了。