本章借用 Starbuzz 网站 header 部分的改造，引出的 CSS Sprites 的知识，结合计算机网络基础知识，提醒同学们计算机专业是一个体系，如果要做精做专，就需要有全面的较专业知识做铺垫。

## 4.1 本课知识点

* CSS Sprites 相关概念
* CSS Sprites 的实践

>[!danger]
> 若有问题务必及时解决，绝不可以拖欠。

___
## 4.2 课程作业

完成课程示例代码对 Starbuzz 网页的修改，正确 commit 新的版本，并上传 GitHub。