各位不妨再来审查下当前的网页，当页面宽度变化时，你会发现页眉 header 的表现并不令人满意。
哪怕时宽屏的时候，页面也缩在了左侧，如果能做成下图的样式，然页面两端的内容自适应到浏览器窗口的两端，显然更符合期待：

![[251header.png]]

>[!question]
> 我们现有的知识足够解决这个问题，请大家说说方案。


---
我们很容易想到的方法是把图像用图片工具分成两份：

```html
<div class="header">
	<img class="headerLogo"   ...>
	<img class="headerSlogan" ...>
</div>
```

再用 CSS 的 float 让图片分列：

```css
   float: right;
```

>[!question]
>  请各位自行完成上面的修改，修正页眉。
